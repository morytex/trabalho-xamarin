﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XF.Atividade_2.Model
{
    public class Aluno
    {
        public Guid Id { get; set; }
        public String RM { get; set; }
        public String Nome { get; set; }
        public String Email { get; set; }
    }
}
