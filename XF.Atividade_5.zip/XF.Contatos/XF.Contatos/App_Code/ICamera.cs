﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XF.Contatos.App_Code
{
    public interface ICamera
    {
        void CapturarFoto();
    }
}
