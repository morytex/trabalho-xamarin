Dupla:
 - Alessandro Moryta / RM:39917
 - Rafael Valverde / RM: 30950